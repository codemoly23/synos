// Removed from: app/(client)/utbildningar/training-page-client.tsx
// Reason: ApplicationFormSection was a dead-end stub — hardcoded text/categories,
// and handleSubmit only did console.log(...) with no backend wiring. Replaced with
// a version that reads CMS content from data.applicationSection and submits to
// /api/upload + /api/form-submissions (type: "training_application").
// Removed on: this session (utbildningar application form wiring task).

function ApplicationFormSection() {
	const [formData, setFormData] = useState({
		name: "",
		email: "",
		phone: "",
		careerType: "",
		message: "",
	});
	const [selectedFile, setSelectedFile] = useState<File | null>(null);
	const [isDropdownOpen, setIsDropdownOpen] = useState(false);
	const fileInputRef = useRef<HTMLInputElement>(null);

	const careerTypes = [
		"Account Manager",
		"Säljrepresentant",
		"Teknisk Support",
		"Marknadsspecialist",
		"Mjukvaruutvecklare",
		"Annat",
	];

	const handleInputChange = (
		e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
	) => {
		const { name, value } = e.target;
		setFormData((prev) => ({ ...prev, [name]: value }));
	};

	const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		if (e.target.files && e.target.files[0]) {
			setSelectedFile(e.target.files[0]);
		}
	};

	const handleSubmit = (e: React.FormEvent) => {
		e.preventDefault();
		// Form submission logic here
		console.log("Form submitted:", { ...formData, file: selectedFile });
	};

	// ...JSX previously used hardcoded strings:
	// badge: "Få svar direkt"
	// heading: "Berätta vad du behöver"
	// subtitle: "Har du frågor om våra utbildningar eller vill boka en plats? Fyll i
	//            formuläret så återkommer en av våra utbildningsspecialister"
	// dropdown bound to formData.careerType / careerTypes array above
	// Submit button had no loading state and never called any API.
}
