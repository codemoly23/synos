// Removed from: components/layout/MobileBottomNav.tsx
// Removed on: 2026-08-19
// Context: scroll handler inside the useEffect that toggles `isHidden` for
// the mobile bottom nav. Previously the bar was always forced visible while
// near the top of the page (currentY <= 60), only hiding/revealing based on
// scroll direction once the user scrolled further down. Also `isHidden`
// used to default to `false` (visible on first load) instead of `true`.
// Replaced with: unconditional `setIsHidden(currentY > lastScrollY.current)`
// on every scroll event, and `useState(true)` for the initial value.
// To restore: bring back the `useState(false)` initial value and the
// currentY > 60 branch below.

const [isHidden, setIsHidden] = useState(false);

// ...inside the scroll handler:
const handleScroll = () => {
	const currentY = window.scrollY;

	if (currentY > 60) {
		setIsHidden(currentY > lastScrollY.current);
	} else {
		setIsHidden(false);
	}
	lastScrollY.current = currentY;
};
