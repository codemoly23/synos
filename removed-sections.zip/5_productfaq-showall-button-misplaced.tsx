/**
 * Removed from: components/products/ProductFAQ.tsx
 * Reason: "Show all" toggle button was hardcoded to render right after the
 * FIRST FAQ item (index === 0) instead of after the LAST displayed item.
 * This caused the button to visually float between question #1 and the
 * remaining questions, both when collapsed and when expanded (showAll state
 * was never checked in the condition either).
 *
 * Original placement: inside the `displayedFaqs.map((faq, index) => (...))`
 * loop, immediately after each FAQ item's closing </motion.div>.
 *
 * Fixed version moves this block outside the .map(), after it renders,
 * so it always sits after the last visible FAQ item.
 */

{/* Show-all toggle sits directly under the first question */}
{index === 0 && !!limit && visibleFaqs.length > limit && (
	<div className="relative flex justify-center pt-6 pb-2">
		{isCapped && (
			<div className="pointer-events-none absolute inset-x-0 -top-2 bottom-10 bg-gradient-to-t from-background to-transparent" />
		)}
		<Button
			variant="outline"
			size="sm"
			className="relative rounded-full text-primary hover:text-primary/80"
			onClick={() => setShowAll((prev) => !prev)}
		>
			{showAll ? (
				<>
					Visa färre <ChevronUp className="ml-1 h-4 w-4" />
				</>
			) : (
				<>
					{showAllLabel} <ChevronDown className="ml-1 h-4 w-4" />
				</>
			)}
		</Button>
	</div>
)}
