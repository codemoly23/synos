﻿// Removed from components/home/YearBadgeSection.tsx

// YearBadgeSVG and MainBadgeSVG SVG components
// Replaced by Reco widget embeds (badge/2021-2025 and yearsInRowBadge)