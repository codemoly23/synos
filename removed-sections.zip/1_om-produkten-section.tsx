// =============================================
// "Om Produkten" Section (ProductLongDescription)
// Removed from: app/(client)/produkter/produkt/[slug]/product-content.tsx
// =============================================

// Import to add back:
import { ProductLongDescription } from "@/components/products/ProductLongDescription";

// JSX to add back (inside <article>):
{product.productDescription && (
  <ProductLongDescription
    description={product.productDescription}
  />
)}
