// =============================================
// Static (non-functional) hero desktop forms
// Removed from:
//   1. app/(client)/klinikutrustning/page.tsx
//   2. app/(client)/produkter/page.tsx
// Both had identical static HTML forms with no submit handler.
// Replaced with <HeroCategoryForm categoryName={...} />
// =============================================

{/* Static form block (was inside the right column div) */}
<div className="space-y-4">
    <div className="grid grid-cols-2 gap-4">
        <div>
            <label className="block text-xs text-white/60 mb-1.5">Förnamn <span className="text-primary">*</span></label>
            <input type="text" placeholder="Ditt förnamn" className="w-full bg-transparent border border-white/20 rounded-md px-3 py-2.5 text-white text-sm placeholder:text-white/30 outline-none" />
        </div>
        <div>
            <label className="block text-xs text-white/60 mb-1.5">Efternamn <span className="text-primary">*</span></label>
            <input type="text" placeholder="Ditt efternamn" className="w-full bg-transparent border border-white/20 rounded-md px-3 py-2.5 text-white text-sm placeholder:text-white/30 outline-none" />
        </div>
    </div>
    <div className="grid grid-cols-2 gap-4">
        <div>
            <label className="block text-xs text-white/60 mb-1.5">Företag <span className="text-primary">*</span></label>
            <input type="text" placeholder="Ditt företagsnamn" className="w-full bg-transparent border border-white/20 rounded-md px-3 py-2.5 text-white text-sm placeholder:text-white/30 outline-none" />
        </div>
        <div>
            <label className="block text-xs text-white/60 mb-1.5">E-post <span className="text-primary">*</span></label>
            <input type="email" placeholder="din.email@exempel.se" className="w-full bg-transparent border border-white/20 rounded-md px-3 py-2.5 text-white text-sm placeholder:text-white/30 outline-none" />
        </div>
    </div>
    <div>
        <label className="block text-xs text-white/60 mb-1.5">När är du intresserad av att ta nästa steg? <span className="text-primary">*</span></label>
        <textarea rows={4} placeholder="Beskriv när det passar er bäst eller andra detaljer..." className="w-full bg-transparent border border-white/20 rounded-md px-3 py-2.5 text-white text-sm placeholder:text-white/30 outline-none resize-none" />
    </div>
    <button type="button" className="w-full py-3 rounded-md bg-primary text-primary-foreground font-medium text-base">
        Skicka förfrågan
    </button>
    <p className="text-center text-xs text-white/40">
        Vi behandlar dina uppgifter konfidentiellt och delar dem inte med tredje part.
    </p>
</div>

// Also removed from produkter/page.tsx desktop — hardcoded title/subtitle:
// <h2>Motus Pro</h2>
// <p>Avancerad laserplattform för professionella behandlingar</p>
// Replaced with {heroTitle} and {heroSubtitle}
