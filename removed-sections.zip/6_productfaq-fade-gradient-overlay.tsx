/**
 * Removed from: components/products/ProductFAQ.tsx (inside the show-all toggle wrapper)
 * Reason: This "fade-out" overlay was meant to visually fade truncated/clipped
 * content above the "Visa alla frågor" button. But FAQ accordion items are never
 * text-clipped (only the answer collapses, the question always renders fully),
 * so there was nothing to fade. It rendered as a stray whitish/gray gradient bar
 * in the empty padding between the last question and the button.
 */

{isCapped && (
	<div className="pointer-events-none absolute inset-x-0 -top-2 bottom-10 bg-gradient-to-t from-background to-transparent" />
)}
