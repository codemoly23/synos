// =============================================
// "Dela" Share Button (ProductShareButtons)
// Removed from: app/(client)/produkter/produkt/[slug]/product-content.tsx
// =============================================

// Import to add back:
import { ProductShareButtons } from "@/components/products/ProductShareButtons";

// JSX to add back (inside <article>, before FAQ section):
{/* Share Button - below image, above Om Produkten */}
<div className="mb-6 flex justify-end">
  <ProductShareButtons
    productName={product.title}
    productUrl={`/produkter/produkt/${product.slug}`}
  />
</div>
