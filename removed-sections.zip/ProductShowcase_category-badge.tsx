// Removed from: components/home/ProductShowcase.tsx
// Removed on: 2026-08-19
// Context: product card in the "Läs mer" showcase grid. This category badge
// was replaced by a product description paragraph in the same slot.
// To restore: swap the `product.description` block below back for this one.

{product.category && (
	<div className="flex flex-wrap gap-2">
		<span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-600">
			{product.category}
		</span>
	</div>
)}
