// =============================================
// Hero Section Product/Machine Images
// Removed from:
//   1. app/(client)/klinikutrustning/page.tsx
//   2. app/(client)/klinikutrustning/[category]/page.tsx
// =============================================

// ── FILE 1: klinikutrustning/page.tsx ──

// MOBILE — machine image (was inside the background image div):
<div className="absolute inset-x-0 top-[6%] h-[50vh] z-10 flex items-center justify-center">
  <div className="relative w-full h-full">
    <ImageComponent
      src="/images/motus-ax-3.jpg"
      alt="Motus Pro"
      fill
      className="object-contain drop-shadow-2xl"
      priority
      sizes="100vw"
    />
  </div>
</div>

// DESKTOP — entire left machine column (was the first child of the grid div):
<div className="relative h-[740px] flex flex-col items-center justify-center">
  {/* Warm floor glow matching background lighting */}
  <div
    className="absolute inset-x-[8%] pointer-events-none z-0"
    style={{
      bottom: '14%',
      height: '90px',
      background: 'radial-gradient(ellipse at 50% 80%, rgba(184,138,58,0.22) 0%, transparent 70%)',
      filter: 'blur(22px)',
    }}
  />
  {/* Product image — anchored to floor */}
  <div className="relative w-full h-[620px] z-10">
    <ImageComponent
      src="/images/motus.png"
      alt="Motus Pro"
      fill
      className="object-contain object-bottom"
      priority
      sizes="700px"
    />
  </div>
  {/* Contact shadow + floor reflection */}
  <div className="relative z-10 w-full shrink-0 -mt-3">
    <div
      className="mx-auto pointer-events-none"
      style={{
        width: '46%',
        height: '16px',
        background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.82) 0%, transparent 70%)',
        filter: 'blur(9px)',
      }}
    />
    <div
      className="w-full mt-1 overflow-hidden"
      style={{
        height: '68px',
        opacity: 0.35,
        maskImage: 'linear-gradient(to bottom, rgba(0,0,0,0.65) 0%, transparent 100%)',
        WebkitMaskImage: 'linear-gradient(to bottom, rgba(0,0,0,0.65) 0%, transparent 100%)',
      }}
    >
      <div className="relative w-full h-[620px]" style={{ transform: 'scaleY(-1)' }}>
        <ImageComponent
          src="/images/motus.png"
          fill
          alt=""
          className="object-contain object-bottom"
          sizes="700px"
        />
      </div>
    </div>
  </div>
</div>

// ── FILE 2: klinikutrustning/[category]/page.tsx (heroConfig branch) ──

// MOBILE — product image (was inside the background image div, heroConfig branch):
<div className="absolute inset-x-0 top-[6%] h-[50vh] z-10 flex items-center justify-center">
  <div className="relative w-full h-full">
    <ImageComponent
      src={heroConfig.mobileImage}
      alt={heroConfig.title}
      fill
      className="object-contain drop-shadow-2xl"
      priority
      sizes="100vw"
    />
  </div>
</div>

// DESKTOP — entire left machine column (heroConfig branch):
<div className="relative h-[740px] flex flex-col items-center justify-center">
  <div
    className="absolute inset-x-[8%] pointer-events-none z-0"
    style={{
      bottom: "14%",
      height: "90px",
      background: "radial-gradient(ellipse at 50% 80%, rgba(184,138,58,0.22) 0%, transparent 70%)",
      filter: "blur(22px)",
    }}
  />
  <div className="relative w-full h-[620px] z-10">
    <ImageComponent
      src={heroConfig.desktopImage}
      alt={heroConfig.title}
      fill
      className="object-contain object-bottom"
      priority
      sizes="700px"
    />
  </div>
  <div className="relative z-10 w-full shrink-0 -mt-3">
    <div
      className="mx-auto pointer-events-none"
      style={{
        width: "46%",
        height: "16px",
        background: "radial-gradient(ellipse at center, rgba(0,0,0,0.82) 0%, transparent 70%)",
        filter: "blur(9px)",
      }}
    />
    <div
      className="w-full mt-1 overflow-hidden"
      style={{
        height: "68px",
        opacity: 0.35,
        maskImage: "linear-gradient(to bottom, rgba(0,0,0,0.65) 0%, transparent 100%)",
        WebkitMaskImage: "linear-gradient(to bottom, rgba(0,0,0,0.65) 0%, transparent 100%)",
      }}
    >
      <div className="relative w-full h-[620px]" style={{ transform: "scaleY(-1)" }}>
        <ImageComponent
          src={heroConfig.desktopImage}
          fill
          alt=""
          className="object-contain object-bottom"
          sizes="700px"
        />
      </div>
    </div>
  </div>
</div>
