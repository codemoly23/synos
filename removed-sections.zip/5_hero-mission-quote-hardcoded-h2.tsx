// Removed from: d:\New folder\synos\app\(client)\om-oss\_components\about-page-client.tsx
// Original lines: 217-222 (inside the "Mission Quote Section - Above Stats", around line 197)
// Reason: replaced hardcoded Swedish text with {data.hero.subtitle} so the admin-editable
// Hero Section "Subtitle" field actually renders on the frontend (was previously ignored).
// To restore: paste this <h2> back in place of {data.hero.subtitle} inside the same block.

<h2 className="text-xl md:text-2xl lg:text-3xl xl:text-4xl font-semibold text-secondary leading-relaxed italic">
	Sveriges ledande leverantör av professionell{" "}
	<span className="text-primary">klinikutrustning</span> och{" "}
	<span className="text-primary">lasermaskiner</span>. Vi kombinerar
	kvalitetsprodukter med utbildning och support i världsklass.
</h2>
