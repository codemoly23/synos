// =============================================
// Remaining hero product/machine images
// Removed from:
//   1. app/(client)/produkter/page.tsx — mobile + desktop machine image
//   2. app/(client)/produkter/produkt/[slug]/product-content.tsx — default hero left column
// =============================================

// ── FILE 1: produkter/page.tsx ──

// MOBILE — machine image (absolute positioned inside background div):
<div className="absolute inset-x-0 top-[6%] h-[50vh] z-10 flex items-center justify-center">
  <div className="relative w-full h-full">
    <ImageComponent
      src="/images/motus-ax-3.jpg"
      alt="Motus Pro"
      fill
      className="object-contain drop-shadow-2xl"
      priority
      sizes="100vw"
    />
  </div>
</div>

// DESKTOP — entire left machine column:
<div className="relative h-[740px] flex flex-col items-center justify-center">
  <div className="absolute inset-x-[8%] pointer-events-none z-0" style={{ bottom: '14%', height: '90px', background: 'radial-gradient(ellipse at 50% 80%, rgba(184,138,58,0.22) 0%, transparent 70%)', filter: 'blur(22px)' }} />
  <div className="relative w-full h-[620px] z-10">
    <ImageComponent src="/images/motus.png" alt="Motus Pro" fill className="object-contain object-bottom" priority sizes="700px" />
  </div>
  <div className="relative z-10 w-full shrink-0 -mt-3">
    <div className="mx-auto pointer-events-none" style={{ width: '46%', height: '16px', background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.82) 0%, transparent 70%)', filter: 'blur(9px)' }} />
    <div className="w-full mt-1 overflow-hidden" style={{ height: '68px', opacity: 0.35, maskImage: 'linear-gradient(to bottom, rgba(0,0,0,0.65) 0%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, rgba(0,0,0,0.65) 0%, transparent 100%)' }}>
      <div className="relative w-full h-[620px]" style={{ transform: 'scaleY(-1)' }}>
        <ImageComponent src="/images/motus.png" fill alt="" className="object-contain object-bottom" sizes="700px" />
      </div>
    </div>
  </div>
</div>

// ── FILE 2: product-content.tsx — default hero (hardcodedHero=false) ──

// DESKTOP — left product image + reflection column:
<div className="relative h-[640px] lg:h-[740px] flex flex-col items-center justify-center">
  <div className="relative w-full h-[520px] lg:h-[620px]">
    <ImageComponent
      src={product.overviewImage || product.productImages?.[0] || ""}
      alt={product.title}
      fill
      className="object-contain drop-shadow-2xl"
      priority
      sizes="(max-width: 1024px) 100vw, 700px"
    />
  </div>
  {/* Reflection */}
  <div className="w-full h-16 overflow-hidden opacity-50 shrink-0 -mt-16"
    style={{ maskImage: 'linear-gradient(to bottom, black 0%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, black 0%, transparent 100%)' }}>
    <div className="relative w-full h-[620px]" style={{ transform: 'scaleY(-1)' }}>
      <ImageComponent
        src={product.overviewImage || product.productImages?.[0] || ""}
        fill alt=""
        className="object-contain object-bottom"
        sizes="(max-width: 1024px) 100vw, 700px"
      />
    </div>
  </div>
</div>
