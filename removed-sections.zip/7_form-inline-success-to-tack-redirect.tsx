// Removed: inline success screens/toasts, replaced with router.push("/tack") redirect
// so GTM destination-based conversion tracking can fire on all lead forms.
// Restore by re-adding the isSuccess/success state + JSX blocks below and reverting
// onSubmit/handleSubmit to call setIsSuccess(true)/setSuccess(true) instead of router.push.

// ============================================================
// 1) components/forms/ContactInquiryForm.tsx
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack")):
//   setIsSuccess(true);
//   reset();
//   setGdprChecked(false);
//   setMarketingChecked(false);
//   toast.success("Tack för ditt meddelande! Vi återkommer inom 24 timmar.");
//   setTimeout(() => setIsSuccess(false), 5000);
// JSX block removed (rendered before the form when isSuccess === true):
// Needs: import { CheckCircle2 } from "lucide-react"; (was part of larger lucide-react import)
/*
	if (isSuccess) {
		return (
			<div className="text-center p-2 sm:p-12 rounded-2xl bg-card border border-border shadow-lg">
				<div className="w-10 h-10 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
					<CheckCircle2 className="h-10 w-10 text-green-600" />
				</div>
				<h2 className="text-2xl md:text-3xl font-bold text-secondary mb-4">Tack för ditt meddelande!</h2>
				<p className="text-lg text-muted-foreground mb-6">Vi har mottagit din förfrågan och återkommer till dig inom 24 timmar.</p>
				<Button variant="outline" onClick={() => setIsSuccess(false)} className="mt-4">Skicka nytt meddelande</Button>
			</div>
		);
	}
*/

// ============================================================
// 2) components/forms/TrainingInquiryForm.tsx
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack")):
//   setIsSuccess(true);
//   reset();
//   setGdprChecked(false);
//   setMarketingChecked(false);
//   setSelectedInterestType(undefined);
//   setSelectedCountry(defaultCountry);
//   toast.success("Tack för din förfrågan! Vi återkommer inom 24 timmar.");
//   setTimeout(() => setIsSuccess(false), 10000);
// JSX block removed:
/*
	if (isSuccess) {
		return (
			<div className="max-w-2xl mx-auto text-center p-8 sm:p-12 rounded-2xl bg-card border border-border shadow-lg">
				<div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
					<CheckCircle2 className="h-10 w-10 text-green-600" />
				</div>
				<h2 className="text-2xl md:text-3xl font-bold text-secondary mb-4">
					Tack för din förfrågan!
				</h2>
				<p className="text-lg text-muted-foreground mb-6">
					Vi har mottagit din förfrågan om våra utbildningar och återkommer
					till dig inom 24 timmar.
				</p>
				<Button
					variant="outline"
					onClick={() => setIsSuccess(false)}
					className="mt-4"
				>
					Skicka ny förfrågan
				</Button>
			</div>
		);
	}
*/

// ============================================================
// 3) components/layout/QuoteRequestModal.tsx
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// handleClose simplified from:
/*
	const handleClose = () => {
		onOpenChange(false);
		setTimeout(() => {
			setIsSuccess(false);
			reset();
			setGdprChecked(false);
		}, 200);
	};
*/
// onSubmit success branch changed from:
//   setIsSuccess(true); reset(); setGdprChecked(false);
// to: onOpenChange(false); router.push("/tack");
// DialogContent className switch changed from:
//   isSuccess ? "bg-white" : "bg-secondary/95"
// to: always "bg-secondary/95"
// Removed "Success State" JSX block:
/*
	{isSuccess && (
		<div className="relative">
			<div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400" />
			<button
				onClick={handleClose}
				className="absolute top-3 right-3 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all duration-200"
				aria-label="Stäng"
			>
				<X className="w-4 h-4" />
			</button>
			<div className="px-6 pt-10 pb-6 text-center">
				<div className="relative w-16 h-16 mx-auto">
					<div className="absolute inset-0 rounded-full border-3 border-emerald-100" />
					<div className="absolute inset-1.5 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-200/50">
						<CheckCircle2 className="w-7 h-7 text-white" strokeWidth={2} />
					</div>
				</div>
				<h2 className="mt-5 text-xl font-bold text-slate-800">
					Tack för din förfrågan!
				</h2>
				<p className="mt-2 text-sm text-slate-500 leading-relaxed">
					Vi har mottagit din offertförfrågan och återkommer inom 24
					timmar med ett prisförslag.
				</p>
				<Button
					onClick={handleClose}
					className="mt-6 w-full h-10 rounded-lg text-sm font-medium bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
				>
					Stäng
				</Button>
			</div>
		</div>
	)}
*/
// The rest of the DialogContent (form state block, previously gated by `{!isSuccess && (...)}`)
// is unwrapped and always rendered now.

// ============================================================
// 4) components/home/TourRequestModal.tsx
// ============================================================
// Same shape of change as QuoteRequestModal above.
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// handleClose simplified from:
/*
	const handleClose = () => {
		onOpenChange(false);
		setTimeout(() => {
			setIsSuccess(false);
			reset();
			setGdprChecked(false);
			setSelectedCountry(defaultCountry);
		}, 200);
	};
*/
// Removed "Success State" JSX block:
/*
	{isSuccess && (
		<div className="relative">
			<div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400" />
			<button
				onClick={handleClose}
				className="absolute top-3 right-3 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-all duration-200"
				aria-label="Stäng"
			>
				<X className="w-4 h-4" />
			</button>
			<div className="px-6 pt-10 pb-6 text-center">
				<div className="relative w-16 h-16 mx-auto">
					<div className="absolute inset-0 rounded-full border-3 border-emerald-100" />
					<div className="absolute inset-1.5 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-200/50">
						<CheckCircle2 className="w-7 h-7 text-white" strokeWidth={2} />
					</div>
				</div>
				<h2 className="mt-5 text-xl font-bold text-slate-800">
					Tack för din förfrågan!
				</h2>
				<p className="mt-2 text-sm text-slate-500 leading-relaxed">
					Vi kontaktar dig inom kort för att boka in din virtuella
					rundtur.
				</p>
				<Button
					onClick={handleClose}
					className="mt-6 w-full h-10 rounded-lg text-sm font-medium bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
				>
					Stäng
				</Button>
			</div>
		</div>
	)}
*/

// ============================================================
// 5) components/product/BrochureRequestModal.tsx
// ============================================================
// State removed: const [success, setSuccess] = useState(false);
// handleSubmit success branch changed from `setSuccess(true);` to `handleClose(false); router.push("/tack");`
// Removed success JSX branch:
/*
	{success ? (
		<div className="flex flex-col items-center gap-3 py-6 text-center">
			<CheckCircle className="h-12 w-12 text-green-500" />
			<h3 className="text-base font-semibold text-foreground">
				Tack för din förfrågan!
			</h3>
			<p className="text-sm text-muted-foreground max-w-xs">
				Vi har mottagit din förfrågan och återkommer till dig med broschyren via e-post.
			</p>
			<Button variant="outline" size="sm" onClick={() => handleClose(false)}>
				Stäng
			</Button>
		</div>
	) : (
		... form unchanged, now rendered unconditionally ...
	)}
*/
// handleClose's `setSuccess(false)` line removed (state deleted).

// ============================================================
// 6) app/(client)/starta-eget/_components/contact-form-section.tsx
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack"), pushEvent/trackLead calls KEPT before redirect):
//   setIsSuccess(true);
//   reset();
//   setGdprChecked(false);
//   toast.success("Tack för din förfrågan! Vi återkommer inom 24 timmar.");
//   setTimeout(() => setIsSuccess(false), 10000);
// JSX block removed:
/*
	if (isSuccess) {
		return (
			<section className="py-16 bg-gradient-to-b from-primary/5 to-white">
				<div className="_container">
					<div className="mx-auto max-w-2xl text-center p-8 sm:p-12 rounded-2xl bg-card border border-border shadow-lg">
						<div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
							<CheckCircle2 className="h-10 w-10 text-green-600" />
						</div>
						<h2 className="text-2xl md:text-3xl font-bold text-secondary mb-4">
							Tack för din förfrågan!
						</h2>
						<p className="text-lg text-muted-foreground mb-6">
							Vi har mottagit din förfrågan om att starta eget och
							återkommer till dig inom 24 timmar.
						</p>
						<Button
							variant="outline"
							onClick={() => setIsSuccess(false)}
							className="mt-4"
						>
							Skicka ny förfrågan
						</Button>
					</div>
				</div>
			</section>
		);
	}
*/

// ============================================================
// 7) app/(client)/om-oss/lediga-tjanster/_components/contact-sidebar.tsx
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack")):
//   setIsSuccess(true);
//   reset();
//   toast.success("Message sent! We'll get back to you soon.");
//   setTimeout(() => setIsSuccess(false), 5000);
// JSX ternary removed (was: {isSuccess ? (...) : (<form>...</form>)} — form now rendered unconditionally):
/*
	isSuccess ? (
		<div className="text-center py-6">
			<div className="w-12 h-12 mx-auto mb-3 rounded-full bg-green-100 flex items-center justify-center">
				<CheckCircle2 className="w-6 h-6 text-green-600" />
			</div>
			<p className="text-sm text-muted-foreground">
				Thanks! We&apos;ll be in touch soon.
			</p>
		</div>
	) : ( ... )
*/

// ============================================================
// 8) app/(client)/om-oss/lediga-tjanster/[slug]/_components/expert-cta-section.tsx
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack"), pushEvent/trackLead calls KEPT before redirect):
//   setIsSuccess(true);
//   reset();
//   toast.success("Your message has been sent! We'll be in touch soon.");
//   setTimeout(() => setIsSuccess(false), 8000);
// JSX ternary removed (form now rendered unconditionally, motion.form no longer gated):
/*
	{isSuccess ? (
		<motion.div
			initial={{ opacity: 0, scale: 0.95 }}
			animate={{ opacity: 1, scale: 1 }}
			className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-10 text-center"
		>
			<div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/20 flex items-center justify-center">
				<CheckCircle2 className="w-8 h-8 text-green-400" />
			</div>
			<h3 className="text-xl font-bold text-white mb-2">
				Tack för ditt meddelande!
			</h3>
			<p className="text-white/70">
				Vi har mottagit din förfrågan och återkommer inom kort.
			</p>
		</motion.div>
	) : ( ... )}
*/

// ============================================================
// 9) app/(client)/utbildningar/training-page-client.tsx
//    (Quick Contact Form — desktop sidebar + mobile variants, both
//    share the same isSuccess state and onSubmit handler)
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack"), pushEvent/trackLead KEPT):
//   setIsSuccess(true);
//   reset();
//   toast.success("Tack! Vi återkommer inom kort.");
//   setTimeout(() => setIsSuccess(false), 5000);
// Two identical JSX ternaries removed (desktop ~line 695, mobile ~line 860),
// each replaced by rendering the <form> unconditionally:
/*
	{isSuccess ? (
		<div className="text-center py-6">
			<div className="w-12 h-12 mx-auto mb-3 rounded-full bg-green-100 flex items-center justify-center">
				<CheckCircle2 className="w-6 h-6 text-green-600" />
			</div>
			<p className="text-sm text-muted-foreground">
				Tack! Vi återkommer inom kort.
			</p>
		</div>
	) : (
		<form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
			... (unchanged form fields) ...
		</form>
	)}
*/

// ============================================================
// 10) app/(client)/starta-eget/starta-eget-page-client.tsx
//     (main /starta-eget page's own inline contact form — distinct
//     from ContactFormSection used on the /starta-eget sub-pages)
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// onSubmit removed lines (replaced by router.push("/tack")):
//   setIsSuccess(true);
//   reset();
//   setGdprChecked(false);
//   toast.success("Tack för din förfrågan! Vi återkommer inom 24 timmar.");
//   setTimeout(() => setIsSuccess(false), 10000);
// JSX block removed (~line 817), replaced by rendering the <motion.form> unconditionally:
/*
	{isSuccess ? (
		<motion.div
			initial={{ opacity: 0, scale: 0.95 }}
			animate={{ opacity: 1, scale: 1 }}
			className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-10 text-center"
		>
			<div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-500/20 flex items-center justify-center">
				<CheckCircle2 className="w-10 h-10 text-green-400" />
			</div>
			<h3 className="text-2xl font-bold text-white mb-3">
				Tack för din förfrågan!
			</h3>
			<p className="text-white/70 mb-6">
				Vi har mottagit din förfrågan och återkommer till dig inom
				24 timmar.
			</p>
			<Button
				variant="outline"
				onClick={() => setIsSuccess(false)}
				className="border-white/20 text-white hover:bg-white/10"
			>
				Skicka ny förfrågan
			</Button>
		</motion.div>
	) : (
		<motion.form ...>...</motion.form>
	)}
*/
// CheckCircle2 removed from lucide-react import (only used in the removed block;
// plain CheckCircle is still used elsewhere in the file and was kept).

// ============================================================
// 11) app/(client)/om-oss/lediga-tjanster/[slug]/_components/job-detail.tsx
//     (ApplicationFormSection — job application form, plain useState
//     not react-hook-form; posts type: "job_application")
// ============================================================
// State removed: const [isSuccess, setIsSuccess] = useState(false);
// handleSubmit removed lines (replaced by router.push("/tack")):
//   setIsSuccess(true);
//   toast.success("Application submitted successfully! We'll get back to you soon.");
//   setTimeout(() => setIsSuccess(false), 10000);
// JSX ternary removed (~line 436), replaced by rendering the <form> unconditionally:
/*
	{isSuccess ? (
		<div className="text-center py-12">
			<div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
				<CheckCircle2 className="w-8 h-8 text-green-600" />
			</div>
			<h3 className="text-2xl font-bold text-secondary mb-2">
				Application Submitted!
			</h3>
			<p className="text-muted-foreground max-w-md mx-auto">
				Thank you for your application. We&apos;ll review your details and get back to you as soon as possible.
			</p>
		</div>
	) : (
		<form onSubmit={handleSubmit}>...</form>
	)}
*/
// CheckCircle2 removed from lucide-react import (only used in the removed block).

// ============================================================
// 12) GDPR-consent gap fix (post-verification follow-up)
//     Live browser testing revealed 3 forms always returned 422
//     from /api/form-submissions because they never collected
//     gdprConsent, which the server schema requires for type:"contact".
//     Added a gdprConsent field + checkbox to each. Removed code below.
// ============================================================

// -- contact-sidebar.tsx --
// Schema before: z.object({ name, email, phone, message }) -- no gdprConsent
// onSubmit body before: { type, subject, fullName, email, phone, message, pageUrl } -- no gdprConsent

// -- expert-cta-section.tsx --
// Schema before: z.object({ name, email, phone, subject, message }) -- no gdprConsent
// onSubmit body before: { type, subject, fullName, email, phone, message, pageUrl } -- no gdprConsent

// -- training-page-client.tsx (Quick Contact "Snabbkontakt") --
// Schema before: z.object({ name, email, phone, message }) -- no gdprConsent
// onSubmit body before: { type, subject, fullName, email, phone, message, pageUrl } -- no gdprConsent
//
// ALSO: this form previously shared ONE useForm()/isSubmitting state at the
// TrainingPageClient component level, with BOTH the desktop-sidebar <form>
// and the mobile-section <form> calling register("name")/register("email")/etc
// on the SAME field names. React Hook Form only tracks one DOM ref per field
// name, so filling the visible instance validated against the other (empty)
// hidden instance, causing spurious "required" errors regardless of gdprConsent.
// Fixed by extracting a `useQuickContactForm()` hook + `DesktopQuickContactForm`/
// `MobileQuickContactForm` components, each with independent state.
