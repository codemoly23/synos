// =============================================
// "Tekniska Specifikationer" Section (Tech Specifications)
// Removed from: app/(client)/produkter/produkt/[slug]/product-content.tsx
// =============================================

// No extra import needed (uses motion from framer-motion, already imported)

// JSX to add back (inside <article>, after BeforeAfterShowcase):
{product?.techSpecifications &&
  product?.techSpecifications?.length > 0 && (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6 }}
      className="mb-12"
      id="specifications"
    >
      <h2 className="text-2xl md:text-3xl font-bold text-secondary mb-6">
        Tekniska Specifikationer
      </h2>
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="divide-y divide-slate-100">
          {product?.techSpecifications?.map(
            (spec, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row sm:justify-between sm:items-center py-4 px-6 hover:bg-slate-50/80 transition-colors duration-200 gap-1 sm:gap-4"
              >
                <span className="font-medium text-foreground">
                  {spec.title}
                </span>
                <span className="text-muted-foreground sm:text-right">
                  {spec.description}
                </span>
              </div>
            )
          )}
        </div>
      </div>
    </motion.section>
  )}
